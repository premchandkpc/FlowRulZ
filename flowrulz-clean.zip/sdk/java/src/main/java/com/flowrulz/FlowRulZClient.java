package com.flowrulz;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public class FlowRulZClient {
  private static final ObjectMapper JSON = new ObjectMapper();

  private final HttpClient http;
  private final String addr;
  private final String apiKey;

  public FlowRulZClient(String address) {
    this(Config.of(address));
  }

  public FlowRulZClient(Config cfg) {
    this.http = cfg.httpClient != null ? cfg.httpClient : HttpClient.newHttpClient();
    this.addr = cfg.address != null ? cfg.address : "http://localhost:8080";
    this.apiKey = cfg.apiKey;
  }

  // -- Modes --
  public static final int MODE_PUBLISH  = 0;
  public static final int MODE_REQUEST  = 1;
  public static final int MODE_REPLY    = 2;
  public static final int MODE_STREAM   = 3;
  public static final int MODE_WORKFLOW = 4;
  public static final int MODE_INTERNAL = 5;

  // -- API --

  public void publish(String topic, Object payload) {
    Event evt = new Event(topic, toBytes(payload), MODE_PUBLISH);
    sendEvent(evt);
  }

  public byte[] request(String service, Object payload, Duration timeout) {
    Event evt = new Event(service, toBytes(payload), MODE_REQUEST);
    return roundTrip(evt, timeout);
  }

  public byte[] execute(String ruleId, Object payload) {
    return execute(ruleId, payload, ExecuteOpts.DEFAULT);
  }

  public byte[] execute(String ruleId, Object payload, ExecuteOpts opts) {
    Event evt = new Event(ruleId, toBytes(payload), MODE_WORKFLOW, opts.headers);
    return roundTrip(evt, opts.timeout);
  }

  public void stream(String topic, Consumer<byte[]> handler) {
    try {
      URI uri = URI.create(addr + "/stream/" + topic);
      HttpRequest.Builder rb = HttpRequest.newBuilder(uri).GET();
      if (apiKey != null) {
        rb.header("Authorization", "Bearer " + apiKey);
      }
      HttpResponse<InputStream> resp = http.send(rb.build(), HttpResponse.BodyHandlers.ofInputStream());
      byte[] buf = new byte[4096];
      int n;
      while ((n = resp.body().read(buf)) != -1) {
        byte[] chunk = new byte[n];
        System.arraycopy(buf, 0, chunk, 0, n);
        handler.accept(chunk);
      }
    } catch (Exception e) {
      throw new RuntimeException("flowrulz stream failed", e);
    }
  }

  // -- internal --

  private void sendEvent(Event evt) {
    try {
      HttpRequest req = buildPost(evt, null);
      http.send(req, HttpResponse.BodyHandlers.discarding());
    } catch (Exception e) {
      throw new RuntimeException("flowrulz publish failed", e);
    }
  }

  private byte[] roundTrip(Event evt, Duration timeout) {
    try {
      HttpRequest req = buildPost(evt, timeout);
      HttpResponse<byte[]> resp = http.send(req, HttpResponse.BodyHandlers.ofByteArray());
      return resp.body();
    } catch (Exception e) {
      throw new RuntimeException("flowrulz request failed", e);
    }
  }

  private HttpRequest buildPost(Event evt, Duration timeout) throws Exception {
    byte[] body = JSON.writeValueAsBytes(evt);
    HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(addr + "/event"))
        .header("Content-Type", "application/json")
        .header("X-FlowRulZ-Mode", String.valueOf(evt.mode))
        .POST(HttpRequest.BodyPublishers.ofByteArray(body));
    if (apiKey != null) {
      b.header("Authorization", "Bearer " + apiKey);
    }
    if (timeout != null) {
      b.timeout(timeout);
    }
    return b.build();
  }

  private static byte[] toBytes(Object payload) {
    try {
      return JSON.writeValueAsBytes(payload);
    } catch (Exception e) {
      throw new IllegalArgumentException("flowrulz marshal failed", e);
    }
  }

  // -- types --

  public static class Config {
    public String address;
    public String apiKey;
    public HttpClient httpClient;

    public static Config of(String address) {
      Config c = new Config();
      c.address = address;
      return c;
    }
  }

  public static class Event {
    public String id;
    public String topic;
    public byte[] payload;
    public Map<String, String> headers;
    public int mode;

    public Event() {}
    public Event(String topic, byte[] payload, int mode) {
      this(topic, payload, mode, null);
    }
    public Event(String topic, byte[] payload, int mode, Map<String, String> headers) {
      this.topic = topic;
      this.payload = payload;
      this.mode = mode;
      this.headers = headers;
    }
  }

  public static class ExecuteOpts {
    public static final ExecuteOpts DEFAULT = new ExecuteOpts(Duration.ofSeconds(30), null);
    public final Duration timeout;
    public final Map<String, String> headers;
    public ExecuteOpts(Duration timeout, Map<String, String> headers) {
      this.timeout = timeout;
      this.headers = headers;
    }
  }
}
