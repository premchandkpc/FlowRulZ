package com.flowrulz;

import static org.junit.Assert.*;

import org.junit.Test;

public class FlowRulZClientTest {

  @Test
  public void testDefaultAddress() {
    FlowRulZClient c = new FlowRulZClient(FlowRulZClient.Config.of("http://localhost:8080"));
    assertNotNull(c);
  }

  @Test
  public void testModeConstants() {
    assertEquals(0, FlowRulZClient.MODE_PUBLISH);
    assertEquals(1, FlowRulZClient.MODE_REQUEST);
    assertEquals(2, FlowRulZClient.MODE_REPLY);
    assertEquals(3, FlowRulZClient.MODE_STREAM);
    assertEquals(4, FlowRulZClient.MODE_WORKFLOW);
    assertEquals(5, FlowRulZClient.MODE_INTERNAL);
  }

  @Test
  public void testExecuteOptsDefault() {
    assertEquals(30, FlowRulZClient.ExecuteOpts.DEFAULT.timeout.getSeconds());
  }
}
