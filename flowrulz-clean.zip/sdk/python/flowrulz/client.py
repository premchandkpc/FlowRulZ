import json
from dataclasses import dataclass, field
from typing import Any, Callable, Optional
from urllib.parse import urljoin

import requests


MODE_PUBLISH = 0
MODE_REQUEST = 1
MODE_REPLY = 2
MODE_STREAM = 3
MODE_WORKFLOW = 4
MODE_INTERNAL = 5


@dataclass
class Event:
    topic: str
    payload: bytes
    mode: int
    id: str = ""
    headers: dict[str, str] = field(default_factory=dict)


@dataclass
class ExecuteOpts:
    timeout: float = 30.0
    headers: dict[str, str] = field(default_factory=dict)


@dataclass
class Config:
    address: str = "http://localhost:8080"
    api_key: str = ""
    http_client: Optional[requests.Session] = None


class FlowRulZClient:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self._http = cfg.http_client or requests.Session()

    def publish(self, topic: str, payload: Any) -> None:
        evt = Event(topic=topic, payload=self._marshal(payload), mode=MODE_PUBLISH)
        self._send_event(evt)

    def request(self, service: str, payload: Any, timeout: float = 0) -> bytes:
        evt = Event(topic=service, payload=self._marshal(payload), mode=MODE_REQUEST)
        return self._roundtrip(evt, timeout)

    def execute(self, rule_id: str, payload: Any, opts: Optional[ExecuteOpts] = None) -> bytes:
        if opts is None:
            opts = ExecuteOpts()
        evt = Event(
            topic=rule_id,
            payload=self._marshal(payload),
            mode=MODE_WORKFLOW,
            headers=opts.headers,
        )
        return self._roundtrip(evt, opts.timeout)

    def stream(self, topic: str, handler: Callable[[bytes], None]) -> None:
        url = urljoin(self.cfg.address, f"/stream/{topic}")
        headers = {}
        if self.cfg.api_key:
            headers["Authorization"] = f"Bearer {self.cfg.api_key}"
        resp = self._http.get(url, headers=headers, stream=True)
        for chunk in resp.iter_content(chunk_size=None):
            if chunk:
                handler(chunk)

    # -- internal --

    def _send_event(self, evt: Event) -> None:
        body = self._marshal(evt)
        headers = {"Content-Type": "application/json", "X-FlowRulZ-Mode": str(evt.mode)}
        if self.cfg.api_key:
            headers["Authorization"] = f"Bearer {self.cfg.api_key}"
        self._http.post(urljoin(self.cfg.address, "/event"), data=body, headers=headers)

    def _roundtrip(self, evt: Event, timeout: float) -> bytes:
        body = self._marshal(evt)
        headers = {"Content-Type": "application/json", "X-FlowRulZ-Mode": str(evt.mode)}
        if self.cfg.api_key:
            headers["Authorization"] = f"Bearer {self.cfg.api_key}"
        kwargs = {}
        if timeout > 0:
            kwargs["timeout"] = timeout
        resp = self._http.post(
            urljoin(self.cfg.address, "/event"), data=body, headers=headers, **kwargs
        )
        return resp.content

    @staticmethod
    def _marshal(obj: Any) -> bytes:
        if isinstance(obj, Event):
            d = {"id": obj.id, "topic": obj.topic, "payload": json.loads(obj.payload), "mode": obj.mode}
            if obj.headers:
                d["headers"] = obj.headers
            return json.dumps(d).encode("utf-8")
        return json.dumps(obj, default=vars).encode("utf-8")
