import json
from unittest.mock import MagicMock, patch

import pytest
import requests

from flowrulz.client import (
    MODE_INTERNAL,
    MODE_PUBLISH,
    MODE_REPLY,
    MODE_REQUEST,
    MODE_STREAM,
    MODE_WORKFLOW,
    Config,
    ExecuteOpts,
    FlowRulZClient,
)


def test_default_config():
    c = FlowRulZClient(Config())
    assert c.cfg.address == "http://localhost:8080"


def test_custom_address():
    c = FlowRulZClient(Config(address="http://localhost:9090"))
    assert c.cfg.address == "http://localhost:9090"


def test_custom_http_client():
    sess = requests.Session()
    c = FlowRulZClient(Config(http_client=sess))
    assert c._http is sess


def test_publish_success():
    responses = {}

    def post(url, **kwargs):
        body = json.loads(kwargs["data"])
        responses["body"] = body
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        return mock_resp

    sess = MagicMock()
    sess.post.side_effect = post
    sess.get = MagicMock()
    c = FlowRulZClient(Config(http_client=sess))
    c.publish("orders", {"id": 42})
    sess.post.assert_called_once()
    args, kwargs = sess.post.call_args
    assert "/event" in args[0]
    assert kwargs["headers"]["X-FlowRulZ-Mode"] == str(MODE_PUBLISH)
    assert kwargs["headers"]["Content-Type"] == "application/json"
    body = json.loads(kwargs["data"])
    assert body["topic"] == "orders"
    assert body["mode"] == MODE_PUBLISH


def test_publish_server_error():
    sess = MagicMock()
    mock_resp = MagicMock()
    mock_resp.status_code = 500
    sess.post.return_value = mock_resp
    c = FlowRulZClient(Config(http_client=sess))
    c.publish("orders", "data")


def test_publish_marshal_error():
    c = FlowRulZClient(Config(http_client=MagicMock()))

    class _Slots:
        __slots__ = ()

    with pytest.raises(TypeError):
        c.publish("t", _Slots())


def test_request_success():
    sess = MagicMock()
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.content = b'{"status":"ok"}'
    sess.post.return_value = mock_resp
    c = FlowRulZClient(Config(http_client=sess))
    resp = c.request("payment", {"amount": "100"})
    assert resp == b'{"status":"ok"}'
    args, kwargs = sess.post.call_args
    assert kwargs["headers"]["X-FlowRulZ-Mode"] == str(MODE_REQUEST)
    body = json.loads(kwargs["data"])
    assert body["topic"] == "payment"
    assert body["mode"] == MODE_REQUEST


def test_request_timeout():
    sess = MagicMock()
    sess.post.side_effect = requests.exceptions.Timeout("timed out")
    c = FlowRulZClient(Config(http_client=sess))
    with pytest.raises(requests.exceptions.Timeout):
        c.request("slow", "data", timeout=0.01)


def test_request_server_error():
    sess = MagicMock()
    mock_resp = MagicMock()
    mock_resp.status_code = 500
    mock_resp.content = b"internal error"
    sess.post.return_value = mock_resp
    c = FlowRulZClient(Config(http_client=sess))
    resp = c.request("svc", "data")
    assert resp == b"internal error"


def test_execute_success():
    sess = MagicMock()
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.content = b'{"result":"completed"}'
    sess.post.return_value = mock_resp
    c = FlowRulZClient(Config(http_client=sess))
    resp = c.execute("order-flow", {"id": "abc"})
    assert resp == b'{"result":"completed"}'
    args, kwargs = sess.post.call_args
    assert kwargs["headers"]["X-FlowRulZ-Mode"] == str(MODE_WORKFLOW)
    body = json.loads(kwargs["data"])
    assert body["topic"] == "order-flow"
    assert body["mode"] == MODE_WORKFLOW


def test_execute_with_headers():
    sess = MagicMock()
    sess.post.return_value.content = b"{}"
    c = FlowRulZClient(Config(http_client=sess))
    opts = ExecuteOpts(headers={"x-trace": "abc123", "x-env": "prod"})
    c.execute("rule-1", "data", opts=opts)
    args, kwargs = sess.post.call_args
    body = json.loads(kwargs["data"])
    assert body["headers"]["x-trace"] == "abc123"
    assert body["headers"]["x-env"] == "prod"


def test_execute_default_timeout():
    sess = MagicMock()
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.content = b"{}"
    sess.post.return_value = mock_resp
    c = FlowRulZClient(Config(http_client=sess))
    resp = c.execute("rule-1", "data")
    assert resp == b"{}"


def test_execute_marshal_error():
    c = FlowRulZClient(Config(http_client=MagicMock()))

    class _Slots:
        __slots__ = ()

    with pytest.raises(TypeError):
        c.execute("rule", _Slots())


def test_stream_success():
    chunks = [b'"event1"\n', b'"event2"\n', b'"event3"\n']

    def iter_content(chunk_size=None):
        yield from chunks

    sess = MagicMock()
    mock_resp = MagicMock()
    mock_resp.iter_content.side_effect = iter_content
    mock_resp.__enter__ = MagicMock(return_value=mock_resp)
    mock_resp.__exit__ = MagicMock(return_value=None)
    sess.get.return_value = mock_resp
    sess.__enter__ = MagicMock(return_value=sess)
    sess.__exit__ = MagicMock(return_value=None)

    c = FlowRulZClient(Config(http_client=sess))
    received = []

    def handler(data):
        received.append(data)

    c.stream("test-topic", handler)
    assert len(received) == 3


def test_stream_connection_error():
    sess = MagicMock()
    sess.get.side_effect = requests.exceptions.ConnectionError("refused")
    c = FlowRulZClient(Config(http_client=sess))
    with pytest.raises(requests.exceptions.ConnectionError):
        c.stream("topic", lambda x: None)


def test_auth_header():
    sess = MagicMock()
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.content = b"{}"
    sess.post.return_value = mock_resp
    c = FlowRulZClient(Config(address="http://localhost:9999", api_key="secret-key", http_client=sess))
    c.publish("t", "data")
    args, kwargs = sess.post.call_args
    assert kwargs["headers"]["Authorization"] == "Bearer secret-key"


def test_mode_constants():
    assert MODE_PUBLISH == 0
    assert MODE_REQUEST == 1
    assert MODE_REPLY == 2
    assert MODE_STREAM == 3
    assert MODE_WORKFLOW == 4
    assert MODE_INTERNAL == 5


def test_execute_empty_opts():
    sess = MagicMock()
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.content = b"{}"
    sess.post.return_value = mock_resp
    c = FlowRulZClient(Config(http_client=sess))
    resp = c.execute("rule", "data")
    assert resp == b"{}"
