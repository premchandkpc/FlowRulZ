package main

import (
	"context"
	"log/slog"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"

	"github.com/premchandkpc/FlowRulZ/server/internal/bootstrap"
	"github.com/premchandkpc/FlowRulZ/server/internal/node"
)

func main() {
	cfg := loadConfig()
	builder := bootstrap.NewNodeBuilder(*cfg).WithDefaults()
	n, err := builder.Build()
	if err != nil {
		slog.Error("node build failed", "error", err)
		os.Exit(1)
	}
	if err := n.Start(context.Background()); err != nil {
		slog.Error("node startup failed", "error", err)
		os.Exit(1)
	}

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	<-ctx.Done()
	slog.Info("shutting down")
	n.Shutdown(context.Background())
}

func loadConfig() *node.Config {
	cfg := node.DefaultConfig()
	if p := os.Getenv("FLOWRULZ_PERSIST_PATH"); p != "" {
		cfg.PersistPath = p
	}
	if a := os.Getenv("FLOWRULZ_HTTP_ADDR"); a != "" {
		cfg.HTTPAddr = a
	}
	if g := os.Getenv("FLOWRULZ_GRPC_ADDR"); g != "" {
		cfg.GRPCAddr = g
	}
	if c := os.Getenv("FLOWRULZ_TLS_CERT"); c != "" {
		cfg.TLSCertFile = c
	}
	if k := os.Getenv("FLOWRULZ_TLS_KEY"); k != "" {
		cfg.TLSKeyFile = k
	}
	if rp := os.Getenv("FLOWRULZ_RAFT_PORT"); rp != "" {
		if port, err := strconv.Atoi(rp); err == nil {
			cfg.RaftPort = port
		}
	}
	if rd := os.Getenv("FLOWRULZ_RAFT_DIR"); rd != "" {
		cfg.RaftDir = rd
	}
	if os.Getenv("FLOWRULZ_RAFT_BOOTSTRAP") == "true" {
		cfg.RaftBootstrap = true
	}
	if t := os.Getenv("FLOWRULZ_TOPIC"); t != "" {
		cfg.Topic = t
	}
	if c := os.Getenv("FLOWRULZ_COMPILER_ADDR"); c != "" {
		cfg.CompilerAddr = c
	}
	if p := os.Getenv("FLOWRULZ_PLUGIN_DIR"); p != "" {
		cfg.PluginDir = p
	}
	if s := os.Getenv("FLOWRULZ_SEEDS"); s != "" {
		cfg.Seeds = strings.Split(s, ",")
	}
	if kb := os.Getenv("FLOWRULZ_KAFKA_BROKERS"); kb != "" {
		cfg.KafkaBrokers = strings.Split(kb, ",")
	}
	if ka := os.Getenv("FLOWRULZ_KAFKA_ACKS"); ka != "" {
		cfg.KafkaAcks = ka
	}
	if os.Getenv("FLOWRULZ_KAFKA_IDEMPOTENT") == "true" {
		cfg.KafkaIdempotent = true
	}
	if cfg.HasTLS() {
		slog.Info("TLS enabled",
			"cert", cfg.TLSCertFile,
			"key", cfg.TLSKeyFile)
	} else {
		slog.Warn("TLS not configured — all traffic is unencrypted. Set FLOWRULZ_TLS_CERT and FLOWRULZ_TLS_KEY for production.")
	}
	return cfg
}
