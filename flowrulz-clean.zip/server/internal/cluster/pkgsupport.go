package cluster

import (
	"context"

	"github.com/hashicorp/raft"

	pkgcluster "github.com/premchandkpc/FlowRulZ/server/pkg/cluster"
)

var _ pkgcluster.ClusterMember = (*ClusterMember)(nil)

type ClusterMember struct {
	inner *RaftCluster
}

func NewClusterMember(rc *RaftCluster) *ClusterMember {
	return &ClusterMember{inner: rc}
}

func (cm *ClusterMember) ID() pkgcluster.MemberID {
	return pkgcluster.MemberID(cm.inner.nodeID)
}

func (cm *ClusterMember) Addr() string {
	return cm.inner.raftBind
}

func (cm *ClusterMember) Start(ctx context.Context) error {
	return cm.inner.Start()
}

func (cm *ClusterMember) Stop(ctx context.Context) error {
	cm.inner.Stop()
	return nil
}

func (cm *ClusterMember) State() pkgcluster.ClusterState {
	if cm.inner.raft == nil {
		return pkgcluster.Follower
	}
	switch cm.inner.raft.State() {
	case raft.Leader:
		return pkgcluster.Leader
	case raft.Candidate:
		return pkgcluster.Candidate
	default:
		return pkgcluster.Follower
	}
}

func (cm *ClusterMember) IsLeader() bool {
	return cm.inner.IsLeader()
}

func (cm *ClusterMember) CurrentTerm() uint64 {
	return cm.inner.CurrentTerm()
}

func (cm *ClusterMember) LeaderID() pkgcluster.MemberID {
	if cm.inner.raft == nil || !cm.inner.IsLeader() {
		return ""
	}
	return pkgcluster.MemberID(cm.inner.nodeID)
}

func (cm *ClusterMember) LeaderAddr() string {
	return cm.inner.LeaderAddr()
}

func (cm *ClusterMember) SubscribeLeaderChanges(fn func(isLeader bool)) pkgcluster.CancelFunc {
	cm.inner.SubscribeLeaderChanges(fn)
	return func() {}
}

func (cm *ClusterMember) SubscribeTermChanges(fn func(term uint64)) pkgcluster.CancelFunc {
	return func() {}
}

func (cm *ClusterMember) Join(memberID pkgcluster.MemberID, addr string) error {
	return cm.inner.Join(string(memberID), addr)
}

func (cm *ClusterMember) Remove(memberID pkgcluster.MemberID) error {
	return cm.inner.Leave(string(memberID))
}

func (cm *ClusterMember) BootstrapCluster() error {
	return cm.inner.BootstrapCluster()
}

// CaptureLeadershipToken captures the current leadership state.
// Use this to implement the fencing pattern against split-brain.
func (cm *ClusterMember) CaptureLeadershipToken() pkgcluster.LeadershipToken {
	return cm.inner.CaptureLeadershipToken()
}

// ValidateLeadershipToken checks if a previously captured token is still valid.
func (cm *ClusterMember) ValidateLeadershipToken(token pkgcluster.LeadershipToken) bool {
	return cm.inner.ValidateLeadershipToken(token)
}
