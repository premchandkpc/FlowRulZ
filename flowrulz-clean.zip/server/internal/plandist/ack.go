package plandist

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"sync/atomic"
	"time"

	pkgplandist "github.com/premchandkpc/FlowRulZ/server/pkg/plandist"
)

type AckMessage = pkgplandist.AckMessage

type AckHandler func(ctx context.Context, msg AckMessage)

func (pd *PlanDistributor) SendAck(ctx context.Context, ruleID string, version uint64, status string) error {
	if pd.ackProducer == nil {
		return fmt.Errorf("plandist: no ACK producer configured")
	}
	msg := AckMessage{
		NodeID:  pd.nodeID,
		RuleID:  ruleID,
		Version: version,
		Status:  status,
	}
	data, err := json.Marshal(msg)
	if err != nil {
		return fmt.Errorf("plandist marshal ack: %w", err)
	}
	return pd.ackProducer.Send(ctx, []byte(fmt.Sprintf("%s:%d", ruleID, version)), data)
}

func (pd *PlanDistributor) WaitForAcks(ctx context.Context, ruleID string, version uint64, quorum int, timeout time.Duration) error {
	// quorum=0 means majority of followers (n-1)/2+1; -1 means all followers
	if quorum == 0 || quorum < 0 {
		if pd.quorumProvider != nil {
			n := pd.quorumProvider.AliveCount()
			if n > 1 {
				if quorum == 0 {
					quorum = (n-1)/2 + 1 // majority of non-leader nodes
				} else {
					quorum = n - 1 // all non-leader nodes
				}
			} else {
				// Single node only (leader itself) — no followers to wait for.
				slog.Info("plandist: no followers for quorum, skipping ack wait", "rule", ruleID, "version", version)
				return nil
			}
		} else {
			// No QuorumProvider wired — this is a configuration bug, not a
			// runtime condition. Silent under-quorum defaults cause split-brain
			// plan activation: a rule version activates cluster-wide after
			// receiving just 1 ack, when majority consensus was intended.
			return fmt.Errorf("plandist: QuorumProvider not configured, cannot determine quorum (rule=%s v=%d); "+
				"wire WithQuorumProvider in NodeBuilder or pass explicit quorum > 0", ruleID, version)
		}
	}
	if quorum <= 0 {
		return nil
	}

	key := ackKey(ruleID, version)
	done := make(chan int, 1)
	received := new(atomic.Int32)
	q32 := int32(quorum)

	pd.pendingAcks.Store(key, pendingAck{done: done, received: received, quorum: q32})
	defer pd.pendingAcks.Delete(key)

	waitCtx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	select {
	case <-waitCtx.Done():
		return fmt.Errorf("plandist: ack timeout for %s v%d (got %d/%d)", ruleID, version, received.Load(), quorum)
	case n := <-done:
		if n >= quorum {
			return nil
		}
		return fmt.Errorf("plandist: insufficient acks for %s v%d (%d/%d)", ruleID, version, n, quorum)
	}
}

func (pd *PlanDistributor) handleAck(ack AckMessage) {
	key := ackKey(ack.RuleID, ack.Version)
	v, ok := pd.pendingAcks.Load(key)
	if !ok {
		return
	}
	pa, ok := v.(pendingAck)
	if !ok {
		return
	}
	n := pa.received.Add(1)
	if n >= pa.quorum {
		select {
		case pa.done <- int(n):
		default:
		}
	}
}

func (pd *PlanDistributor) RecordAck(msg AckMessage) {
	pd.handleAck(msg)
}

type pendingAck struct {
	done     chan int
	received *atomic.Int32
	quorum   int32
}

func ackKey(ruleID string, version uint64) string {
	return fmt.Sprintf("%s:%d", ruleID, version)
}

func AckMessageFromBytes(data []byte) (*AckMessage, error) {
	var msg AckMessage
	if err := json.Unmarshal(data, &msg); err != nil {
		return nil, err
	}
	return &msg, nil
}
