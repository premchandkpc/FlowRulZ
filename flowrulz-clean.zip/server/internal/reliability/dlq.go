package reliability

import (
	"context"
	"encoding/json"
	"log/slog"
	"os"
	"path/filepath"
	"regexp"
	"sync"
	"time"

	"github.com/premchandkpc/FlowRulZ/server/internal/transport"
)

var safeIDRegex = regexp.MustCompile(`^[a-zA-Z0-9_\-]+$`)

const DefaultDLQTopic = "_flowrulz_dlq"

type DeadLetterEntry struct {
	ID         string    `json:"id"`
	RuleID     string    `json:"rule_id"`
	Topic      string    `json:"topic"`
	Partition  int32     `json:"partition"`
	Offset     int64     `json:"offset"`
	Body       []byte    `json:"body"`
	Error      string    `json:"error"`
	FailedAt   time.Time `json:"failed_at"`
	RetryCount int       `json:"retry_count"`
}

type DLQ struct {
	mu       sync.RWMutex
	entries  []*DeadLetterEntry
	maxSize  int
	replayFn func(ctx context.Context, entry *DeadLetterEntry) error
	producer transport.MessageProducer
	topic    string
	dir      string
}

type DLQOption func(*DLQ)

func WithDLQProducer(p transport.MessageProducer) DLQOption {
	return func(d *DLQ) { d.producer = p }
}

func WithDLQDir(dir string) DLQOption {
	return func(d *DLQ) { d.dir = dir }
}

func NewDLQ(maxSize int, opts ...DLQOption) *DLQ {
	if maxSize <= 0 {
		maxSize = 10000
	}
	d := &DLQ{
		entries: make([]*DeadLetterEntry, 0),
		maxSize: maxSize,
		topic:   DefaultDLQTopic,
	}
	for _, o := range opts {
		o(d)
	}
	if d.dir != "" {
		d.loadFromDir()
	}
	return d
}

func (d *DLQ) SetReplayFn(fn func(ctx context.Context, entry *DeadLetterEntry) error) {
	d.mu.Lock()
	defer d.mu.Unlock()
	d.replayFn = fn
}

func (d *DLQ) Send(entry *DeadLetterEntry) error {
	if entry.ID == "" || !safeIDRegex.MatchString(entry.ID) {
		return &InvalidEntryIDError{ID: entry.ID}
	}

	d.mu.Lock()
	if len(d.entries) >= d.maxSize {
		oldest := d.entries[0]
		d.entries = d.entries[1:]
		d.removePersisted(oldest.ID)
	}
	entry.FailedAt = time.Now()
	d.entries = append(d.entries, entry)
	entryCopy := *entry
	d.mu.Unlock()

	d.persistEntry(&entryCopy)

	slog.Warn("dlq: message", "rule", entry.RuleID, "id", entry.ID, "error", entry.Error)

	if d.producer != nil {
		data, err := json.Marshal(&entryCopy)
		if err != nil {
			slog.Error("dlq: marshal error for kafka", "error", err)
			return nil
		}
		if err := d.producer.Send(context.Background(), []byte(entry.ID), data); err != nil {
			slog.Error("dlq: kafka produce error", "error", err)
			return err
		}
	}
	return nil
}

func (d *DLQ) loadFromDir() {
	entries, err := os.ReadDir(d.dir)
	if err != nil {
		return
	}
	d.mu.Lock()
	defer d.mu.Unlock()
	for _, e := range entries {
		if e.IsDir() || filepath.Ext(e.Name()) != ".json" {
			continue
		}
		data, err := os.ReadFile(filepath.Join(d.dir, e.Name()))
		if err != nil {
			continue
		}
		var entry DeadLetterEntry
		if err := json.Unmarshal(data, &entry); err != nil {
			continue
		}
		d.entries = append(d.entries, &entry)
	}
	slog.Info("dlq: restored entries", "count", len(d.entries), "dir", d.dir)
}

func (d *DLQ) persistEntry(entry *DeadLetterEntry) {
	if d.dir == "" {
		return
	}
	path := filepath.Join(d.dir, entry.ID+".json")
	data, err := json.Marshal(entry)
	if err != nil {
		slog.Error("dlq: marshal error", "error", err)
		return
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, data, 0600); err != nil {
		slog.Error("dlq: write error", "error", err)
		return
	}
	if err := os.Rename(tmp, path); err != nil {
		slog.Error("dlq: rename error", "error", err)
	}
}

func (d *DLQ) removePersisted(id string) {
	if d.dir == "" {
		return
	}
	path := filepath.Join(d.dir, id+".json")
	os.Remove(path)
	os.Remove(path + ".tmp")
}

func (d *DLQ) LoadFromTopic(ctx context.Context) {
	slog.Warn("dlq: LoadFromTopic is a no-op; use LoadFromMessages to rebuild from any source")
}

// LoadFromMessages idempotently loads dead letter entries from raw JSON messages.
// Deduplicates against existing entries by ID. Returns the number of new entries added.
func (d *DLQ) LoadFromMessages(ctx context.Context, messages [][]byte) int {
	d.mu.Lock()
	existing := make(map[string]bool, len(d.entries))
	for _, e := range d.entries {
		existing[e.ID] = true
	}
	d.mu.Unlock()

	added := 0
	for _, raw := range messages {
		var entry DeadLetterEntry
		if err := json.Unmarshal(raw, &entry); err != nil {
			slog.Warn("dlq: unmarshal error during rebuild", "error", err)
			continue
		}
		if entry.ID == "" || !safeIDRegex.MatchString(entry.ID) {
			slog.Warn("dlq: rejected entry with invalid ID", "id", entry.ID)
			continue
		}

		d.mu.Lock()
		if existing[entry.ID] {
			d.mu.Unlock()
			continue
		}
		if len(d.entries) >= d.maxSize {
			oldest := d.entries[0]
			d.entries = d.entries[1:]
			d.removePersisted(oldest.ID)
		}
		d.entries = append(d.entries, &entry)
		existing[entry.ID] = true
		d.mu.Unlock()

		d.persistEntry(&entry)
		added++
	}

	slog.Info("dlq: rebuild from messages completed", "added", added, "total", d.Len())
	return added
}

func (d *DLQ) Replay(ctx context.Context, id string) error {
	d.mu.Lock()
	var entry *DeadLetterEntry
	var idx int = -1
	for i, e := range d.entries {
		if e.ID == id {
			entry = e
			idx = i
			break
		}
	}
	if entry == nil {
		d.mu.Unlock()
		return nil
	}
	d.entries = append(d.entries[:idx], d.entries[idx+1:]...)
	fn := d.replayFn
	d.mu.Unlock()

	d.removePersisted(id)

	if fn != nil {
		entry.RetryCount++
		return fn(ctx, entry)
	}
	return nil
}

// ReplayAll attempts to replay all dead letter entries.
// WARNING: If the process crashes during replay, entries that were cleared from
// memory but not yet replayed will be lost. This is an acceptable trade-off because:
// 1. The alternative (atomic remove-per-entry) introduces duplicate entry bugs
// 2. Replay failures are rare in practice
// 3. Entries are persisted to disk, so a full restart can reload them
func (d *DLQ) ReplayAll(ctx context.Context) int {
	d.mu.Lock()
	entries := make([]*DeadLetterEntry, len(d.entries))
	copy(entries, d.entries)
	d.entries = d.entries[:0]
	fn := d.replayFn
	d.mu.Unlock()

	if fn == nil {
		return 0
	}

	count := 0
	for _, entry := range entries {
		entry.RetryCount++
		replayErr := func() (err error) {
			defer func() {
				if r := recover(); r != nil {
					err = &replayPanicError{value: r}
				}
			}()
			return fn(ctx, entry)
		}()
		if replayErr != nil {
			if pe, ok := replayErr.(*replayPanicError); ok {
				slog.Error("dlq: replay panic, re-queuing", "id", entry.ID, "panic", pe.value)
			}
			_ = d.Send(entry)
			continue
		}
		d.removePersisted(entry.ID)
		count++
	}
	return count
}

type replayPanicError struct {
	value any
}

func (e *replayPanicError) Error() string {
	return "replay panic"
}

func (d *DLQ) List() []*DeadLetterEntry {
	d.mu.RLock()
	defer d.mu.RUnlock()
	out := make([]*DeadLetterEntry, len(d.entries))
	copy(out, d.entries)
	return out
}

func (d *DLQ) Len() int {
	d.mu.RLock()
	defer d.mu.RUnlock()
	return len(d.entries)
}

func (d *DLQ) Clear() {
	d.mu.Lock()
	entries := d.entries
	d.entries = d.entries[:0]
	d.mu.Unlock()

	if d.dir != "" {
		for _, e := range entries {
			d.removePersisted(e.ID)
		}
	}
}

func (d *DLQ) ToJSON() ([]byte, error) {
	d.mu.RLock()
	defer d.mu.RUnlock()
	return json.Marshal(d.entries)
}

// InvalidEntryIDError is returned when a DLQ entry ID contains unsafe characters.
type InvalidEntryIDError struct {
	ID string
}

func (e *InvalidEntryIDError) Error() string {
	return "invalid DLQ entry ID: must contain only alphanumeric, dash, or underscore characters"
}
