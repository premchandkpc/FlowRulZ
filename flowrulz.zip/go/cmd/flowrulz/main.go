package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"os"
	"os/signal"
	"strings"
	"syscall"

	"github.com/premchandkpc/FlowRulZ/go/internal/execnode"
	"github.com/premchandkpc/FlowRulZ/simulator"
	"github.com/premchandkpc/FlowRulZ/simulator/config"
	"github.com/premchandkpc/FlowRulZ/simulator/network"
	"github.com/premchandkpc/FlowRulZ/simulator/scenarios"
)

func main() {
	if len(os.Args) > 1 && os.Args[1] == "simulate" {
		runSimulate(os.Args[2:])
		return
	}

	cfg := execnode.NewConfig()
	if p := os.Getenv("FLOWRULZ_PERSIST_PATH"); p != "" {
		cfg.PersistPath = p
	}
	if p := os.Getenv("FLOWRULZ_EXEC_STATE_DIR"); p != "" {
		cfg.ExecStateDir = p
	}
	if a := os.Getenv("FLOWRULZ_HTTP_ADDR"); a != "" {
		cfg.HTTPAddr = a
	}
	if g := os.Getenv("FLOWRULZ_GRPC_ADDR"); g != "" {
		cfg.GRPCAddr = g
	}
	if t := os.Getenv("FLOWRULZ_TOPIC"); t != "" {
		cfg.Topic = t
	}
	if c := os.Getenv("FLOWRULZ_COMPILER_ADDR"); c != "" {
		cfg.CompilerAddr = c
	}
	if p := os.Getenv("FLOWRULZ_PLUGIN_DIR"); p != "" {
		cfg.PluginDir = p
	}
	if s := os.Getenv("FLOWRULZ_SEEDS"); s != "" {
		cfg.Seeds = strings.Split(s, ",")
	}
	if kb := os.Getenv("FLOWRULZ_KAFKA_BROKERS"); kb != "" {
		cfg.KafkaBrokers = strings.Split(kb, ",")
	}
	if ka := os.Getenv("FLOWRULZ_KAFKA_ACKS"); ka != "" {
		cfg.KafkaAcks = ka
	}
	if os.Getenv("FLOWRULZ_KAFKA_IDEMPOTENT") == "true" {
		cfg.KafkaIdempotent = true
	}

	node := execnode.New(cfg)
	node.Start()
}

func runSimulate(args []string) {
	log.SetFlags(0)

	fs := flag.NewFlagSet("simulate", flag.ExitOnError)

	nodes := fs.Int("nodes", 3, "number of execution nodes")
	workers := fs.Int("workers", 4, "workers per node")
	scenario := fs.String("scenario", "black-friday", "scenario name")
	rate := fs.Int("rate", 0, "requests per second (overrides scenario)")
	duration := fs.Duration("duration", 0, "test duration (overrides scenario)")
	speed := fs.Float64("speed", 1.0, "simulation speed multiplier")
	dash := fs.Bool("dashboard", true, "enable web dashboard")
	dashAddr := fs.String("dashboard-addr", ":8081", "dashboard listen address")
	drop := fs.Bool("drop", false, "enable packet dropping")
	slow := fs.Bool("slow", false, "enable slow network")
	scenariosFlag := fs.Bool("scenarios", false, "list available scenarios")
	verbose := fs.Bool("verbose", false, "verbose output")
	interactive := fs.Bool("interactive", false, "interactive mode with admin API (no auto-stop)")

	fs.Parse(args)

	if *scenariosFlag {
		fmt.Println("Available scenarios:")
		for _, s := range scenarios.All {
			fmt.Printf("  %-16s %s\n", s.Name, s.Description)
		}
		os.Exit(0)
	}

	if !*interactive && *scenario != "" && scenarios.ByName(*scenario) == nil {
		fmt.Fprintf(os.Stderr, "unknown scenario: %s\n", *scenario)
		fmt.Fprintf(os.Stderr, "use --scenarios to list available\n")
		os.Exit(1)
	}

	cfg := config.SimConfig{
		Nodes:         *nodes,
		Workers:       *workers,
		Scenario:      *scenario,
		Duration:      *duration,
		Rate:          *rate,
		Speed:         *speed,
		Dashboard:     *dash,
		DashboardAddr: *dashAddr,
		Verbose:       *verbose,
	}

	if *drop || *slow {
		cfg.Chaos = network.ChaosConfig{
			DropPackets:  *drop,
			SlowNetwork:  *slow,
			SlowFactor:   3.0,
			DuplicatePct: 1.0,
		}
	}

	sim := simulator.New(cfg)

	if *interactive {
		sim.RegisterAdminHandlers()

		ctx, cancel := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
		defer cancel()

		sim.Dispatcher.StartAll()
		if cfg.Dashboard {
			sim.Dashboard.Start()
		}
		log.Printf("simulator: interactive mode on %s — API at /api/admin/{send,rules,services}", cfg.DashboardAddr)
		<-ctx.Done()
		log.Printf("shutting down...")
		sim.Stop()
		return
	}

	if err := sim.Run(); err != nil {
		log.Fatalf("simulator error: %v", err)
	}
}
