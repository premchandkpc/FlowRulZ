use crate::bytecode::plan::ExecutionPlan;
use crate::dsl::{compiler::Compiler, lexer, optimizer, parser};
use crate::error::FfiError;
use crate::executor::plugin;
use crate::executor::{StepResult, VM};
use crate::memory::{arena::Arena, intern::InternTable};

static INTERN_TABLE: once_cell::sync::Lazy<InternTable> = once_cell::sync::Lazy::new(|| {
    let table = InternTable::new();
    table.prefill(&[
        "content-type",
        "content-length",
        "x-correlation-id",
        "x-trace-id",
        "x-flowrulz-chunk-id",
        "x-flowrulz-chunk-index",
        "x-flowrulz-chunk-total",
    ]);
    table
});

fn write_error(ptr: *mut u8, cap: usize, len: *mut usize, msg: &str) {
    if ptr.is_null() || cap == 0 || len.is_null() {
        return;
    }
    let bytes = msg.as_bytes();
    let n = bytes.len().min(cap);
    unsafe {
        std::ptr::copy_nonoverlapping(bytes.as_ptr(), ptr, n);
        *len = n;
    }
}

fn read_slice<'a>(ptr: *const u8, len: usize) -> Option<&'a [u8]> {
    if ptr.is_null() {
        return None;
    }
    Some(unsafe { std::slice::from_raw_parts(ptr, len) })
}

fn read_str<'a>(ptr: *const u8, len: usize) -> Option<&'a str> {
    let slice = read_slice(ptr, len)?;
    std::str::from_utf8(slice).ok()
}

#[no_mangle]
pub unsafe extern "C" fn flowrulz_compile(
    dsl_ptr: *const u8,
    dsl_len: usize,
    rule_id_ptr: *const u8,
    rule_id_len: usize,
    out_ptr: *mut u8,
    out_cap: usize,
    out_len: *mut usize,
    err_ptr: *mut u8,
    err_cap: usize,
    err_len: *mut usize,
) -> i32 {
    let dsl_str = match read_str(dsl_ptr, dsl_len) {
        Some(s) => s,
        None => return FfiError::NullPointer.code(),
    };

    let rule_id = match read_str(rule_id_ptr, rule_id_len) {
        Some(s) => s,
        None => "default",
    };

    let tokens = match lexer::lex(dsl_str) {
        Ok(t) => t,
        Err(e) => {
            write_error(err_ptr, err_cap, err_len, &format!("flowrulz_compile lex: {}", e));
            return FfiError::Lex.code();
        }
    };

    let pipeline = match parser::parse(&tokens) {
        Ok(p) => p,
        Err(e) => {
            write_error(err_ptr, err_cap, err_len, &format!("flowrulz_compile parse: {}", e));
            return FfiError::Parse.code();
        }
    };

    let opt = optimizer::Optimizer::new();
    let optimized = opt.optimize(&pipeline);

    let compiler = Compiler::new();
    let plan = match compiler.compile(&optimized, rule_id) {
        Ok(p) => p,
        Err(e) => {
            write_error(err_ptr, err_cap, err_len, &format!("flowrulz_compile: {}", e));
            return FfiError::Compile.code();
        }
    };

    let plan_bytes = match bincode::serialize(&plan) {
        Ok(b) => b,
        Err(e) => {
            write_error(err_ptr, err_cap, err_len, &format!("flowrulz_compile serialize: {}", e));
            return FfiError::Serialize.code();
        }
    };

    if plan_bytes.len() > out_cap {
        write_error(
            err_ptr,
            err_cap,
            err_len,
            &format!(
                "flowrulz_compile: output buffer too small ({} > {})",
                plan_bytes.len(),
                out_cap
            ),
        );
        return FfiError::BufferTooSmall.code();
    }

    unsafe {
        std::ptr::copy_nonoverlapping(plan_bytes.as_ptr(), out_ptr, plan_bytes.len());
        *out_len = plan_bytes.len();
    }

    0
}

#[no_mangle]
pub unsafe extern "C" fn flowrulz_execute(
    ctx_id: u64,
    plan_ptr: *const u8,
    plan_len: usize,
    body_ptr: *const u8,
    body_len: usize,
    caller_cb: extern "C" fn(u64, u16, *const u8, usize, *mut u8, *mut usize) -> i32,
    out_ptr: *mut u8,
    out_cap: usize,
    out_len: *mut usize,
    err_ptr: *mut u8,
    err_cap: usize,
    err_len: *mut usize,
    msg_id_ptr: *const u8,
    msg_id_len: usize,
    corr_id_ptr: *const u8,
    corr_id_len: usize,
    trace_id_ptr: *const u8,
    trace_id_len: usize,
    partition: u32,
    offset: i64,
) -> i32 {
    let plan_slice = match read_slice(plan_ptr, plan_len) {
        Some(s) => s,
        None => return FfiError::NullPointer.code(),
    };

    let plan: ExecutionPlan = match bincode::deserialize(plan_slice) {
        Ok(p) => p,
        Err(e) => {
            write_error(err_ptr, err_cap, err_len, &format!("flowrulz_execute deserialize: {}", e));
            return FfiError::Deserialize.code();
        }
    };

    let body = match read_slice(body_ptr, body_len) {
        Some(s) => s,
        None => return FfiError::NullPointer.code(),
    };

    let arena = Arena::new();
    let caller_wrapper = move |svc_id: u16, b: &[u8], _timeout: u64| -> Result<Vec<u8>, String> {
        let mut resp_buf = vec![0u8; 65536];
        let mut resp_len: usize = 0;

        let rc = caller_cb(
            ctx_id,
            svc_id,
            b.as_ptr(),
            b.len(),
            resp_buf.as_mut_ptr(),
            &mut resp_len as *mut usize,
        );

        if rc != 0 {
            Err(format!("caller returned {}", rc))
        } else {
            resp_buf.truncate(resp_len);
            Ok(resp_buf)
        }
    };

    let mut ctx = crate::bytecode::execution::ExecutionContext::from_body(body.to_vec());

    if !msg_id_ptr.is_null() {
        if let Some(s) = read_str(msg_id_ptr, msg_id_len) {
            ctx.event.id = s.to_string();
        }
    }
    if !corr_id_ptr.is_null() {
        if let Some(s) = read_str(corr_id_ptr, corr_id_len) {
            ctx.event.metadata.correlation_id = s.to_string();
        }
    }
    if !trace_id_ptr.is_null() {
        if let Some(s) = read_str(trace_id_ptr, trace_id_len) {
            ctx.event.metadata.trace_id = s.to_string();
        }
    }
    ctx.event.metadata.partition = partition;
    ctx.event.metadata.offset = offset;

    let mut vm = VM::new(&plan, ctx, arena, &caller_wrapper);

    match vm.run() {
        Ok(()) => {
            let result = &vm.ctx.body;
            if result.len() <= out_cap {
                unsafe {
                    std::ptr::copy_nonoverlapping(result.as_ptr(), out_ptr, result.len());
                    *out_len = result.len();
                }
            }
            if !err_ptr.is_null() && err_cap > 0 {
                unsafe {
                    *err_len = 0;
                }
            }
            0
        }
        Err(e) => {
            write_error(err_ptr, err_cap, err_len, &format!("flowrulz_execute: {}", e));
            FfiError::Exec.code()
        }
    }
}

#[no_mangle]
pub unsafe extern "C" fn flowrulz_msg_alloc(size: usize) -> *mut u8 {
    if size == 0 {
        return std::ptr::null_mut();
    }
    let layout = std::alloc::Layout::from_size_align(size, 1).unwrap();
    std::alloc::alloc(layout)
}

#[no_mangle]
pub unsafe extern "C" fn flowrulz_msg_release(ptr: *mut u8) {
    if !ptr.is_null() {
        let layout = std::alloc::Layout::new::<usize>();
        std::alloc::dealloc(ptr, layout);
    }
}

#[no_mangle]
pub unsafe extern "C" fn flowrulz_intern(s_ptr: *const u8, s_len: usize) -> u16 {
    let s = match read_str(s_ptr, s_len) {
        Some(s) => s,
        None => return 0,
    };
    INTERN_TABLE.intern(s)
}

#[no_mangle]
pub unsafe extern "C" fn flowrulz_intern_lookup(id: u16, out_ptr: *mut u8, out_len: *mut usize) {
	if out_ptr.is_null() || out_len.is_null() {
		return;
	}
	if let Some(s) = INTERN_TABLE.lookup(id) {
		let bytes = s.as_bytes();
		unsafe {
			std::ptr::copy_nonoverlapping(bytes.as_ptr(), out_ptr, bytes.len());
			*out_len = bytes.len();
		}
	}
}

#[no_mangle]
pub unsafe extern "C" fn flowrulz_span_size() -> usize {
    std::mem::size_of::<crate::tracing::Span>()
}

#[no_mangle]
pub unsafe extern "C" fn flowrulz_get_spans(out_ptr: *mut u8, out_cap: usize) -> usize {
    if out_ptr.is_null() || out_cap == 0 {
        return 0;
    }
    let out_slice = unsafe { std::slice::from_raw_parts_mut(out_ptr, out_cap) };
    crate::tracing::SPAN_BUFFER.with(|buf| {
        buf.borrow_mut().drain(out_slice)
    })
}

#[no_mangle]
pub unsafe extern "C" fn flowrulz_execute_step(
    ctx_id: u64,
    plan_ptr: *const u8,
    plan_len: usize,
    ctx_bytes_ptr: *const u8,
    ctx_bytes_len: usize,
    resp_ptr: *const u8,
    resp_len: usize,
    caller_cb: extern "C" fn(u64, u16, *const u8, usize, *mut u8, *mut usize) -> i32,
    out_ptr: *mut u8,
    out_cap: usize,
    out_len: *mut usize,
    err_ptr: *mut u8,
    err_cap: usize,
    err_len: *mut usize,
    pending_svc_id: *mut u16,
    pending_body_ptr: *mut u8,
    pending_body_cap: usize,
    pending_body_len: *mut usize,
    ctx_out_ptr: *mut u8,
    ctx_out_cap: usize,
    ctx_out_len: *mut usize,
) -> i32 {
    let plan_slice = match read_slice(plan_ptr, plan_len) {
        Some(s) => s,
        None => return FfiError::NullPointer.code(),
    };
    let plan: ExecutionPlan = match bincode::deserialize(plan_slice) {
        Ok(p) => p,
        Err(_) => return FfiError::Deserialize.code(),
    };

    let ctx: crate::bytecode::execution::ExecutionContext = if ctx_bytes_len > 0 && !ctx_bytes_ptr.is_null() {
        let slice = match read_slice(ctx_bytes_ptr, ctx_bytes_len) {
            Some(s) => s,
            None => return FfiError::NullPointer.code(),
        };
        match bincode::deserialize(slice) {
            Ok(c) => c,
            Err(_) => return FfiError::Deserialize.code(),
        }
    } else {
        let body = Vec::new();
        crate::bytecode::execution::ExecutionContext::from_body(body)
    };

    let arena = crate::memory::arena::Arena::new();
    let caller_wrapper = move |svc_id: u16, b: &[u8], _timeout: u64| -> Result<Vec<u8>, String> {
        let mut resp_buf = vec![0u8; 65536];
        let mut resp_len: usize = 0;
        let rc = caller_cb(
            ctx_id,
            svc_id,
            b.as_ptr(),
            b.len(),
            resp_buf.as_mut_ptr(),
            &mut resp_len as *mut usize,
        );
        if rc != 0 {
            Err(format!("caller returned {}", rc))
        } else {
            resp_buf.truncate(resp_len);
            Ok(resp_buf)
        }
    };

    let mut vm = VM::new(&plan, ctx, arena, &caller_wrapper);
    let response = if !resp_ptr.is_null() {
        Some(read_slice(resp_ptr, resp_len).unwrap_or(&[]))
    } else {
        None
    };

    match vm.step(response) {
        Ok(step_result) => match step_result {
            StepResult::Done => {
                let result = &vm.ctx.body;
                if !out_ptr.is_null() && out_cap > 0 {
                    let n = result.len().min(out_cap);
                    unsafe {
                        std::ptr::copy_nonoverlapping(result.as_ptr(), out_ptr, n);
                        *out_len = n;
                    }
                }
                let ctx_bytes = bincode::serialize(&vm.ctx).unwrap_or_default();
                if !ctx_out_ptr.is_null() && ctx_out_cap > 0 {
                    let n = ctx_bytes.len().min(ctx_out_cap);
                    unsafe {
                        std::ptr::copy_nonoverlapping(ctx_bytes.as_ptr(), ctx_out_ptr, n);
                        *ctx_out_len = n;
                    }
                }
                0
            }
            StepResult::Continue => {
                let ctx_bytes = bincode::serialize(&vm.ctx).unwrap_or_default();
                if !ctx_out_ptr.is_null() && ctx_out_cap > 0 {
                    let n = ctx_bytes.len().min(ctx_out_cap);
                    unsafe {
                        std::ptr::copy_nonoverlapping(ctx_bytes.as_ptr(), ctx_out_ptr, n);
                        *ctx_out_len = n;
                    }
                }
                2
            }
            StepResult::Pending { svc_id, body } => {
                if !pending_svc_id.is_null() {
                    unsafe { *pending_svc_id = svc_id; }
                }
                if !pending_body_ptr.is_null() && !pending_body_len.is_null() && pending_body_cap > 0 {
                    let n = body.len().min(pending_body_cap);
                    unsafe {
                        std::ptr::copy_nonoverlapping(body.as_ptr(), pending_body_ptr, n);
                        *pending_body_len = n;
                    }
                }
                let ctx_bytes = bincode::serialize(&vm.ctx).unwrap_or_default();
                if !ctx_out_ptr.is_null() && ctx_out_cap > 0 {
                    let n = ctx_bytes.len().min(ctx_out_cap);
                    unsafe {
                        std::ptr::copy_nonoverlapping(ctx_bytes.as_ptr(), ctx_out_ptr, n);
                        *ctx_out_len = n;
                    }
                }
                1
            }
            StepResult::Delay(ms) => {
                if !pending_svc_id.is_null() {
                    unsafe { *pending_svc_id = ms as u16; }
                }
                if !pending_body_ptr.is_null() && !pending_body_len.is_null() && pending_body_cap >= 8 {
                    unsafe {
                        std::ptr::write(pending_body_ptr as *mut u64, ms);
                        *pending_body_len = 8;
                    }
                }
                let ctx_bytes = bincode::serialize(&vm.ctx).unwrap_or_default();
                if !ctx_out_ptr.is_null() && ctx_out_cap > 0 {
                    let n = ctx_bytes.len().min(ctx_out_cap);
                    unsafe {
                        std::ptr::copy_nonoverlapping(ctx_bytes.as_ptr(), ctx_out_ptr, n);
                        *ctx_out_len = n;
                    }
                }
                3
            }
        },
        Err(e) => {
            write_error(err_ptr, err_cap, err_len, &format!("step: {}", e));
            FfiError::Exec.code()
        }
    }
}

#[no_mangle]
pub unsafe extern "C" fn flowrulz_register_plugin(
    name_ptr: *const u8,
    name_len: usize,
    wasm_ptr: *const u8,
    wasm_len: usize,
) -> i32 {
    let name = match read_str(name_ptr, name_len) {
        Some(s) => s,
        None => return FfiError::InvalidUtf8.code(),
    };
    let wasm_bytes = match read_slice(wasm_ptr, wasm_len) {
        Some(s) => s,
        None => return FfiError::NullPointer.code(),
    };
    plugin::register(name, wasm_bytes);
    0
}

#[no_mangle]
pub unsafe extern "C" fn flowrulz_plan_services(
    plan_ptr: *const u8,
    plan_len: usize,
    out_ptr: *mut u8,
    out_cap: usize,
    out_len: *mut usize,
) -> i32 {
    if out_ptr.is_null() || out_len.is_null() {
        return FfiError::NullPointer.code();
    }
    let plan_slice = match read_slice(plan_ptr, plan_len) {
        Some(s) => s,
        None => return FfiError::NullPointer.code(),
    };
    let plan: ExecutionPlan = match bincode::deserialize(plan_slice) {
        Ok(p) => p,
        Err(_) => return FfiError::Deserialize.code(),
    };
    let json = serde_json::to_string(&plan.services.entries()).unwrap_or_default();
    let bytes = json.as_bytes();
    let n = bytes.len().min(out_cap);
    unsafe {
        std::ptr::copy_nonoverlapping(bytes.as_ptr(), out_ptr, n);
        *out_len = n;
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn flowrulz_plan_complexity(plan_ptr: *const u8, plan_len: usize) -> u32 {
    let plan_slice = match read_slice(plan_ptr, plan_len) {
        Some(s) => s,
        None => return 0,
    };
    match bincode::deserialize::<ExecutionPlan>(plan_slice) {
        Ok(plan) => plan.complexity_score,
        Err(_) => 0,
    }
}
